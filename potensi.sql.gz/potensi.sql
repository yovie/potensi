-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 07, 2016 at 02:28 PM
-- Server version: 5.5.49-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `potensi`
--

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groups` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `groups`) VALUES
(1, 'Guru'),
(2, 'Siswa');

-- --------------------------------------------------------

--
-- Table structure for table `jawaban`
--

CREATE TABLE IF NOT EXISTS `jawaban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teks` varchar(30) NOT NULL,
  `skor` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `jawaban`
--

INSERT INTO `jawaban` (`id`, `teks`, `skor`) VALUES
(1, 'Sangat sesuai', 4),
(2, 'Sesuai', 3),
(3, 'Tidak sesuai', 2),
(4, 'Sangat tidak sesuai', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pertanyaan`
--

CREATE TABLE IF NOT EXISTS `pertanyaan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `standar_kompetensi_id` int(11) NOT NULL DEFAULT '0',
  `kompetensi_id` int(11) NOT NULL DEFAULT '0',
  `indikator_id` int(11) NOT NULL DEFAULT '0',
  `teks` text NOT NULL,
  `jenis` enum('standar','kompetensi','indikator','pertanyaan') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `pertanyaan`
--

INSERT INTO `pertanyaan` (`id`, `standar_kompetensi_id`, `kompetensi_id`, `indikator_id`, `teks`, `jenis`) VALUES
(1, 0, 0, 0, 'A. ada ada saja', 'standar'),
(3, 0, 0, 0, 'B. Test lagi test', 'standar'),
(4, 1, 0, 0, 'A.1. Coba-coba lagi', 'kompetensi'),
(6, 1, 0, 0, 'A.2. Mantap', 'kompetensi'),
(7, 3, 0, 0, 'B.1. Aku lagi test', 'kompetensi'),
(8, 0, 7, 0, 'B.1.1. Indikator B', 'indikator'),
(10, 0, 4, 0, 'A.1.1. Indikator a.1.1', 'indikator'),
(11, 0, 4, 0, 'A.1.2. Indikator lagi a.1.2', 'indikator'),
(12, 0, 6, 0, 'A.2.1. Indikator nya', 'indikator'),
(13, 0, 7, 0, 'B.1.2. Indikator B 222', 'indikator'),
(15, 0, 0, 10, 'Pertanyaan A.1.1. saja', 'pertanyaan'),
(16, 0, 0, 12, 'Pertanyaan A.2.1.', 'pertanyaan'),
(17, 0, 0, 0, 'C. Standar Baru\r\n', 'standar'),
(18, 17, 0, 0, 'C.1. Kompetensi baru', 'kompetensi'),
(19, 0, 18, 0, 'C.1.1. indikator c.1.1', 'indikator'),
(20, 0, 18, 0, 'C.1.2. indikator c.1.2', 'indikator'),
(22, 0, 0, 20, 'Ini juga', 'pertanyaan'),
(23, 0, 0, 19, 'sebelum ini juga', 'pertanyaan');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE IF NOT EXISTS `profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(40) NOT NULL,
  `nama` varchar(70) NOT NULL,
  `tempat_lahir` varchar(40) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `etnis` varchar(50) NOT NULL,
  `kontak` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `foto` varchar(100) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `sekolah` varchar(50) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `nip`, `nama`, `tempat_lahir`, `tanggal_lahir`, `etnis`, `kontak`, `email`, `foto`, `kelas`, `sekolah`, `group_id`) VALUES
(1, '112', 'Guru', '', '0000-00-00', '', '022 234 344', 'guru@gmail.com', '/files/users.png', '', '', 1),
(2, '222', 'joko', 'Barru', '1988-07-04', 'Bugis', '234', 'joko@gmail.com', '/files/users.png', 'XI-IPA-1', 'SMP N 1', 2),
(4, '222', 'Jono', 'Bandung', '1990-07-04', 'Sunda', '022 344 344', 'jono@gmail.com', '/files/photo/1467614022-alqalam.jpg', 'XI-IPA-1', 'SMP N 1', 2);

-- --------------------------------------------------------

--
-- Table structure for table `setup`
--

CREATE TABLE IF NOT EXISTS `setup` (
  `key` varchar(20) NOT NULL,
  `value` varchar(100) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tes`
--

CREATE TABLE IF NOT EXISTS `tes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `mulai` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `selesai` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tes_jawaban`
--

CREATE TABLE IF NOT EXISTS `tes_jawaban` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tes_id` int(11) NOT NULL,
  `pertanyaan_id` int(11) NOT NULL,
  `jawaban_id` int(11) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `tpwd` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT 'penanda aktif tidaknya user',
  `group_id` int(11) DEFAULT NULL,
  `last_login` bigint(20) DEFAULT NULL,
  `ref_id` int(20) DEFAULT NULL COMMENT 'ref ke tabel profil',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `ref_id` (`ref_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `tpwd`, `status`, `group_id`, `last_login`, `ref_id`) VALUES
(1, 'guru', '77e69c137812518e359196bb2f5e9bb9', '', 1, 1, NULL, 1),
(2, 'joko', '9ba0009aa81e794e628a04b51eaf7d7f', '', 1, 2, NULL, 2),
(3, 'jono', '42867493d4d4874f331d288df0044baa', 'jono', 1, 2, NULL, 4);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`ref_id`) REFERENCES `profiles` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
